# Cocos MCP Server internal test build

This package is intended for functional evaluation with Cocos Creator 3.7 or
newer.

The HTTP service listens on `127.0.0.1` only. Keep it on a trusted test
machine, do not expose it through a public proxy, and stop the server when the
test is complete.

Run the complete regression suite before distributing a changed package:

```bash
npm test
```

The test suite covers the extension lifecycle, tool catalog, tool
configuration manager, MCP protocol, simple HTTP endpoint, port fallback,
local discovery file, panel contract, and package artifact scan.
