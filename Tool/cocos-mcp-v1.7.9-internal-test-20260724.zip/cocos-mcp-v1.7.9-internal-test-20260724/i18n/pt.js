"use strict";

module.exports = {
  extension_name: "Cocos MCP Servidor",
  description: "Servidor AI MCP para Cocos Creator 3.8",
  panel_title: "Servidor MCP",
  open_panel: "Abrir painel MCP",
};
