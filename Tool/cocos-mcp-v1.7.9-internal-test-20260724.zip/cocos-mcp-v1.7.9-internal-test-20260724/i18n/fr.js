"use strict";

module.exports = {
  extension_name: "Cocos MCP Serveur",
  description: "Serveur AI MCP pour Cocos Creator 3.8",
  panel_title: "Serveur MCP",
  open_panel: "Ouvrir le panneau MCP",
};
