"use strict";

module.exports = {
  extension_name: "Cocos MCP Server",
  description: "Máy chủ AI MCP cho Cocos Creator 3.8",
  panel_title: "Máy chủ MCP",
  open_panel: "Mở bảng điều khiển MCP",
};
