"use strict";

module.exports = {
  extension_name: "Cocos MCP Сервер",
  description: "AI MCP сервер для Cocos Creator 3.8",
  panel_title: "MCP Сервер",
  open_panel: "Открыть панель MCP",
};
