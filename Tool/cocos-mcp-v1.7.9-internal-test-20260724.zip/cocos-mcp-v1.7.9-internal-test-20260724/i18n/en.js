"use strict";

module.exports = {
  extension_name: "Cocos MCP Server",
  description: "AI MCP Server for Cocos Creator 3.8",
  panel_title: "MCP Server",
  open_panel: "Open MCP Panel",
};
