"use strict";

module.exports = {
  extension_name: "Cocos MCP 服务器",
  description: "适用于 Cocos Creator 3.8 的 AI MCP 服务器",
  panel_title: "MCP 服务器",
  open_panel: "打开 MCP 面板",
};
