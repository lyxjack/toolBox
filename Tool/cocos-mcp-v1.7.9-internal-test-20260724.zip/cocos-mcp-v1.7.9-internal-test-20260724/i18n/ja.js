"use strict";

module.exports = {
  extension_name: "Cocos MCP サーバー",
  description: "Cocos Creator 3.8 用 AI MCP サーバー",
  panel_title: "MCP サーバー",
  open_panel: "MCP パネルを開く",
};
