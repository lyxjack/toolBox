"use strict";

module.exports = {
  extension_name: "Cocos MCP Server",
  description: "AI MCP Server für Cocos Creator 3.8",
  panel_title: "MCP Server",
  open_panel: "MCP-Panel öffnen",
};
