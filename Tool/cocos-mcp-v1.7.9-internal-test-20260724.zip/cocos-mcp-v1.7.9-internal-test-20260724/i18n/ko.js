"use strict";

module.exports = {
  extension_name: "Cocos MCP 서버",
  description: "Cocos Creator 3.8용 AI MCP 서버",
  panel_title: "MCP 서버",
  open_panel: "MCP 패널 열기",
};
