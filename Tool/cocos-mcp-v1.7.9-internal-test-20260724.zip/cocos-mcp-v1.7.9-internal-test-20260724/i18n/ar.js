"use strict";

module.exports = {
  extension_name: "خادم Cocos MCP",
  description: "خادم AI MCP لـ Cocos Creator 3.8",
  panel_title: "خادم MCP",
  open_panel: "فتح لوحة MCP",
};
