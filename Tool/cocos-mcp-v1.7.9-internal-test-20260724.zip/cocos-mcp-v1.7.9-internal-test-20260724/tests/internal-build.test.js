"use strict";

const assert = require("node:assert/strict");
const crypto = require("node:crypto");
const fs = require("node:fs");
const http = require("node:http");
const net = require("node:net");
const os = require("node:os");
const path = require("node:path");
const { once } = require("node:events");
const test = require("node:test");

const ROOT = path.resolve(__dirname, "..");
const BASELINE_TOOL_HASH =
  "ceb3a49dd2d03434f8219bc42d5fe84cb62c5f0645eb8f99346b9e988695ee60";
const BASELINE_TOOL_NAMES = [
  "cocos_scene",
  "cocos_node",
  "cocos_component",
  "cocos_prefab",
  "cocos_asset",
  "cocos_editor",
  "cocos_view",
  "cocos_composite",
  "cocos_knowledge",
  "cocos_validate",
  "cocos_template",
  "cocos_capture",
  "cocos_builder",
  "cocos_animation",
  "cocos_spine",
  "cocos_label",
];

function makeProject() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "cocos-mcp-test-"));
  fs.mkdirSync(path.join(root, "settings"), { recursive: true });
  return root;
}

function removeProject(root) {
  fs.rmSync(root, { recursive: true, force: true });
}

function setEditor(projectRoot, overrides = {}) {
  const calls = [];
  globalThis.Editor = {
    Project: { path: projectRoot },
    Message: {
      async request(...args) {
        calls.push(args);
        return {};
      },
    },
    Panel: {
      async open(...args) {
        calls.push(["Panel.open", ...args]);
      },
      define(definition) {
        return definition;
      },
    },
    ...overrides,
  };
  return calls;
}

function stable(value) {
  if (Array.isArray(value)) return value.map(stable);
  if (value && typeof value === "object") {
    const output = {};
    for (const key of Object.keys(value).sort()) {
      output[key] = stable(value[key]);
    }
    return output;
  }
  return value;
}

function digest(value) {
  return crypto
    .createHash("sha256")
    .update(JSON.stringify(stable(value)))
    .digest("hex");
}

function request(port, options = {}) {
  const body =
    options.body === undefined
      ? undefined
      : typeof options.body === "string"
        ? options.body
        : JSON.stringify(options.body);
  const headers = { ...(options.headers || {}) };
  if (body !== undefined && headers["Content-Type"] === undefined) {
    headers["Content-Type"] = "application/json";
  }
  if (body !== undefined) headers["Content-Length"] = Buffer.byteLength(body);

  return new Promise((resolve, reject) => {
    const req = http.request(
      {
        hostname: "127.0.0.1",
        port,
        path: options.path || "/",
        method: options.method || "GET",
        headers,
      },
      (response) => {
        const chunks = [];
        response.on("data", (chunk) => chunks.push(chunk));
        response.on("end", () => {
          const text = Buffer.concat(chunks).toString("utf8");
          resolve({
            status: response.statusCode,
            headers: response.headers,
            text,
            json: text ? JSON.parse(text) : null,
          });
        });
      },
    );
    req.on("error", reject);
    if (body !== undefined) req.write(body);
    req.end();
  });
}

async function freePort() {
  const probe = net.createServer();
  probe.listen(0, "127.0.0.1");
  await once(probe, "listening");
  const port = probe.address().port;
  const closed = once(probe, "close");
  probe.close();
  await closed;
  return port;
}

async function closeMcpServer(server) {
  const listener = server.httpServer;
  const closed = listener ? once(listener, "close") : Promise.resolve();
  server.stop();
  await closed;
}

async function openAndCloseEventStream(port) {
  return new Promise((resolve, reject) => {
    const req = http.get(
      { hostname: "127.0.0.1", port, path: "/mcp" },
      (response) => {
        response.once("data", (chunk) => {
          const result = {
            status: response.statusCode,
            headers: response.headers,
            text: chunk.toString("utf8"),
          };
          response.destroy();
          resolve(result);
        });
      },
    );
    req.on("error", reject);
  });
}

function walkFiles(directory) {
  const output = [];
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    if (entry.name === "node_modules" || entry.name === "tests") continue;
    const fullPath = path.join(directory, entry.name);
    if (entry.isDirectory()) output.push(...walkFiles(fullPath));
    else output.push(fullPath);
  }
  return output;
}

test("settings persist only the functional server fields", () => {
  const project = makeProject();
  setEditor(project);
  const settings = require("../dist/settings");

  fs.writeFileSync(
    path.join(project, "settings", "mcp-server.json"),
    JSON.stringify({
      port: 3123,
      autoStart: true,
      enableDebugLog: true,
      maxConnections: 22,
      allowedOrigins: ["https://old.example"],
      arbitraryLegacyField: "ignored",
    }),
  );

  assert.deepEqual(settings.readSettings(), {
    port: 3123,
    autoStart: true,
    enableDebugLog: true,
    maxConnections: 22,
  });
  assert.deepEqual(
    Object.keys(settings.saveSettings({ port: 65536 })).sort(),
    ["autoStart", "enableDebugLog", "maxConnections", "port"],
  );

  settings.saveVersionMarker("1.7.9-test");
  assert.equal(settings.getInstalledVersion(), "1.7.9-test");
  const sample = { id: "a", name: "A", tools: [] };
  assert.deepEqual(
    settings.importToolConfiguration(
      settings.exportToolConfiguration(sample),
    ),
    sample,
  );
  assert.throws(
    () => settings.importToolConfiguration("{}"),
    /Invalid JSON format/,
  );
  removeProject(project);
});

test("tool catalog is byte-semantically identical to the pre-change baseline", async () => {
  const project = makeProject();
  setEditor(project);
  const { MCPServer } = require("../dist/mcp-server");
  const server = new MCPServer();
  const tools = await server.setupTools();

  assert.deepEqual(
    tools.map((tool) => tool.name),
    BASELINE_TOOL_NAMES,
  );
  assert.equal(digest(tools), BASELINE_TOOL_HASH);
  assert.equal(tools.length, 16);
  assert.ok(
    tools.every(
      (tool) =>
        tool.description &&
        tool.inputSchema &&
        tool.inputSchema.type === "object",
    ),
  );
  removeProject(project);
});

test("tool manager supports configuration CRUD, toggles, export and import", () => {
  const project = makeProject();
  setEditor(project);
  const { ToolManager } = require("../dist/tools/tool-manager");
  const manager = new ToolManager();

  const initial = manager.getToolManagerState();
  assert.equal(initial.success, true);
  assert.equal(initial.availableTools.length, 16);
  assert.equal(initial.configurations.length, 1);
  assert.equal(initial.maxConfigSlots, 5);

  const created = manager.createConfiguration("Regression", "Automated test");
  const updated = manager.updateConfiguration(created.id, {
    name: "Regression updated",
  });
  assert.equal(updated.name, "Regression updated");

  manager.setCurrentConfiguration(created.id);
  manager.updateToolStatus(created.id, "cocos", "scene", false);
  manager.updateToolStatusBatch(created.id, [
    { category: "cocos", name: "node", enabled: false },
    { category: "cocos", name: "asset", enabled: true },
  ]);
  assert.equal(manager.getEnabledTools().length, 14);

  const exported = manager.exportConfiguration(created.id);
  const parsed = JSON.parse(exported);
  assert.equal(parsed.name, "Regression updated");
  manager.deleteConfiguration(created.id);
  assert.equal(
    manager.getConfigurations().some((entry) => entry.id === created.id),
    false,
  );
  const imported = manager.importConfiguration(exported);
  assert.equal(imported.name, "Regression updated");
  assert.ok(
    fs.existsSync(path.join(project, "settings", "tool-manager.json")),
  );
  removeProject(project);
});

test("client configuration output remains compatible and contains only local HTTP data", () => {
  const {
    MCP_CLIENTS,
    buildServerEntry,
  } = require("../dist/mcp-client-configs");
  const { MCPConfigManager } = require("../dist/mcp-config-manager");
  const config = MCPConfigManager.generateCocosServerConfig(3456);
  assert.deepEqual(config, {
    serverName: "cocos-creator",
    serverUrl: "http://127.0.0.1:3456/mcp",
  });

  for (const clientId of Object.keys(MCP_CLIENTS)) {
    const output = MCPConfigManager.generateConfigContent(clientId, config);
    assert.match(output, /127\.0\.0\.1:3456\/mcp/);
    const entry = buildServerEntry(clientId, config);
    assert.equal(
      Object.values(entry).some(
        (value) =>
          value === config.serverUrl ||
          (typeof value === "string" && value.includes(config.serverUrl)),
      ),
      true,
    );
    assert.equal(Object.hasOwn(entry, "headers"), false);
    assert.equal(Object.hasOwn(entry, "env"), false);
  }

  const commands = MCPConfigManager.generateCLICommands(config);
  assert.match(commands.claude, /--transport http/);
  assert.match(commands.gemini, /--transport http/);
});

test("JSON and TOML client configuration CRUD preserve unrelated settings", () => {
  const fakeHome = fs.mkdtempSync(path.join(os.tmpdir(), "cocos-mcp-home-"));
  const previousHome = process.env.HOME;
  process.env.HOME = fakeHome;

  try {
    const cursorFile = path.join(fakeHome, ".cursor", "mcp.json");
    const codexFile = path.join(fakeHome, ".codex", "config.toml");
    fs.mkdirSync(path.dirname(cursorFile), { recursive: true });
    fs.mkdirSync(path.dirname(codexFile), { recursive: true });
    fs.writeFileSync(
      cursorFile,
      JSON.stringify({ unrelated: { keep: true } }),
      "utf8",
    );
    fs.writeFileSync(codexFile, 'model = "test-model"\n', "utf8");

    const { MCPConfigManager } = require("../dist/mcp-config-manager");
    const server = MCPConfigManager.generateCocosServerConfig(3456);

    for (const clientId of ["cursor", "codex-cli"]) {
      const added = MCPConfigManager.addServer(clientId, server);
      assert.equal(added.success, true);
      assert.equal(MCPConfigManager.serverExists(clientId, server.serverName), true);
      assert.deepEqual(MCPConfigManager.listServers(clientId), [
        server.serverName,
      ]);
      assert.equal(fs.existsSync(added.backupPath), true);

      const removed = MCPConfigManager.removeServer(
        clientId,
        server.serverName,
      );
      assert.equal(removed.success, true);
      assert.equal(
        MCPConfigManager.serverExists(clientId, server.serverName),
        false,
      );
      assert.equal(fs.existsSync(removed.backupPath), true);
    }

    assert.deepEqual(MCPConfigManager.readConfig("cursor").unrelated, {
      keep: true,
    });
    assert.equal(
      MCPConfigManager.readConfig("codex-cli").model,
      "test-model",
    );
  } finally {
    if (previousHome === undefined) delete process.env.HOME;
    else process.env.HOME = previousHome;
    fs.rmSync(fakeHome, { recursive: true, force: true });
  }
});

test("extension message contract and lifecycle work end to end", async () => {
  const project = makeProject();
  const port = await freePort();
  const calls = setEditor(project);
  const settings = require("../dist/settings");
  settings.saveSettings({
    port,
    autoStart: false,
    enableDebugLog: false,
    maxConnections: 10,
  });

  const mainPath = require.resolve("../dist/main");
  delete require.cache[mainPath];
  const extension = require(mainPath);
  const packageJson = require("../package.json");
  extension.load();
  await new Promise((resolve) => setImmediate(resolve));

  const methodNames = Object.keys(extension.methods);
  assert.equal(
    methodNames.some((name) =>
      /checkLicense|activateLicense|subscription|machineId|login|logout/i.test(
        name,
      ),
    ),
    false,
  );

  for (const [messageName, contribution] of Object.entries(
    packageJson.contributions.messages,
  )) {
    assert.doesNotMatch(
      messageName,
      /license|subscription|machine-id|login|logout|device-removed/i,
    );
    for (const methodName of contribution.methods) {
      if (methodName.startsWith("default.")) continue;
      assert.equal(
        typeof extension.methods[methodName],
        "function",
        `${messageName} points to missing method ${methodName}`,
      );
    }
  }

  await extension.methods.openPanel();
  assert.deepEqual(calls[0], ["Panel.open", "cocos-mcp-server"]);
  assert.equal((await extension.methods.getToolManagerState()).success, true);

  const update = await extension.methods.updateSettings({
    port,
    autoStart: false,
    enableDebugLog: true,
    maxConnections: 7,
    allowedOrigins: ["https://ignored.example"],
  });
  assert.deepEqual(update.settings, {
    port,
    autoStart: false,
    enableDebugLog: true,
    maxConnections: 7,
  });

  await extension.methods.startServer();
  const health = await request(port, { path: "/health" });
  assert.equal(health.status, 200);
  assert.equal(health.json.tools, 16);
  await extension.methods.stopServer();
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(extension.methods.getServerStatus().running, false);
  extension.unload();
  removeProject(project);
});

test("MCP HTTP protocol works without any credential input", async () => {
  const project = makeProject();
  setEditor(project);
  const port = await freePort();
  const { MCPServer } = require("../dist/mcp-server");
  const server = new MCPServer({ port, maxConnections: 10 });
  await server.start();

  try {
    assert.equal(server.httpServer.address().address, "127.0.0.1");
    const discoveryFile = path.join(
      project,
      "settings",
      ".mcp-port.json",
    );
    assert.equal(fs.existsSync(discoveryFile), true);
    assert.equal(JSON.parse(fs.readFileSync(discoveryFile)).port, port);

    const health = await request(port, { path: "/health" });
    assert.equal(health.status, 200);
    assert.deepEqual(
      {
        status: health.json.status,
        transport: health.json.transport,
        protocolVersion: health.json.protocolVersion,
        tools: health.json.tools,
      },
      {
        status: "ok",
        transport: "streamable-http",
        protocolVersion: "2025-03-26",
        tools: 16,
      },
    );

    const initialized = await request(port, {
      method: "POST",
      path: "/mcp",
      body: {
        jsonrpc: "2.0",
        id: 1,
        method: "initialize",
        params: {
          protocolVersion: "2025-03-26",
          capabilities: {},
          clientInfo: { name: "regression", version: "1" },
        },
      },
    });
    assert.equal(initialized.status, 200);
    assert.equal(initialized.json.result.serverInfo.name, "cocos-mcp-server");
    const sessionId = initialized.headers["mcp-session-id"];
    assert.ok(sessionId);

    const notification = await request(port, {
      method: "POST",
      path: "/mcp",
      headers: { "Mcp-Session-Id": sessionId },
      body: {
        jsonrpc: "2.0",
        method: "notifications/initialized",
      },
    });
    assert.equal(notification.status, 202);

    const listed = await request(port, {
      method: "POST",
      path: "/mcp",
      headers: { "Mcp-Session-Id": sessionId },
      body: { jsonrpc: "2.0", id: 2, method: "tools/list" },
    });
    assert.equal(listed.status, 200);
    assert.equal(digest(listed.json.result.tools), BASELINE_TOOL_HASH);

    const called = await request(port, {
      method: "POST",
      path: "/mcp",
      headers: { "Mcp-Session-Id": sessionId },
      body: {
        jsonrpc: "2.0",
        id: 3,
        method: "tools/call",
        params: {
          name: "cocos_knowledge",
          arguments: { topic: "tool_guide", query: "scene" },
        },
      },
    });
    assert.equal(called.status, 200);
    const toolPayload = JSON.parse(called.json.result.content[0].text);
    assert.equal(toolPayload.success, true);

    const simple = await request(port, {
      method: "POST",
      path: "/api/cocos/knowledge",
      body: { topic: "tool_guide", query: "scene" },
    });
    assert.equal(simple.status, 200);
    assert.equal(simple.json.success, true);
    assert.equal(simple.json.result.success, true);

    const invalidTool = await request(port, {
      method: "POST",
      path: "/mcp",
      body: {
        jsonrpc: "2.0",
        id: 4,
        method: "tools/call",
        params: { name: "cocos_missing", arguments: {} },
      },
    });
    assert.match(invalidTool.json.error.message, /not found/);

    const malformed = await request(port, {
      method: "POST",
      path: "/mcp",
      body: "{not-json",
    });
    assert.equal(malformed.status, 400);
    assert.match(malformed.json.error, /Invalid JSON/);

    const options = await request(port, {
      method: "OPTIONS",
      path: "/mcp",
    });
    assert.equal(options.status, 204);
    assert.equal(options.headers["access-control-allow-origin"], "*");

    const eventStream = await openAndCloseEventStream(port);
    assert.equal(eventStream.status, 200);
    assert.match(eventStream.headers["content-type"], /text\/event-stream/);
    assert.match(eventStream.text, /connection established/);

    const deleted = await request(port, {
      method: "DELETE",
      path: "/mcp",
      headers: { "Mcp-Session-Id": sessionId },
    });
    assert.equal(deleted.status, 200);
    assert.equal(deleted.json.ok, true);

    const missing = await request(port, { path: "/missing" });
    assert.equal(missing.status, 404);
  } finally {
    await closeMcpServer(server);
  }

  assert.equal(
    fs.existsSync(path.join(project, "settings", ".mcp-port.json")),
    false,
  );
  removeProject(project);
});

test("mutating calls debounce scene saves", async () => {
  const project = makeProject();
  setEditor(project);
  const { MCPServer } = require("../dist/mcp-server");
  const server = new MCPServer();
  await server.setupTools();
  server.cocosTools.execute = async () => ({ success: true });
  let saves = 0;
  server.doAutoSave = async () => {
    saves += 1;
  };
  const originalDelay = MCPServer.AUTO_SAVE_DELAY;
  MCPServer.AUTO_SAVE_DELAY = 10;
  try {
    await server.executeToolCall("cocos_node", { action: "modify" });
    await server.executeToolCall("cocos_node", { action: "modify" });
    await new Promise((resolve) => setTimeout(resolve, 40));
    assert.equal(saves, 1);
  } finally {
    MCPServer.AUTO_SAVE_DELAY = originalDelay;
    server.stop();
    removeProject(project);
  }
});

test("occupied configured port falls back and reports the actual endpoint", async () => {
  const project = makeProject();
  setEditor(project);
  const blocker = net.createServer();
  blocker.listen(0, "127.0.0.1");
  await once(blocker, "listening");
  const requestedPort = blocker.address().port;
  const { MCPServer } = require("../dist/mcp-server");
  const server = new MCPServer({ port: requestedPort });

  try {
    await server.start();
    const status = server.getStatus();
    assert.equal(status.running, true);
    assert.notEqual(status.port, requestedPort);
    assert.deepEqual(server.portFallback, {
      requestedPort,
      actualPort: status.port,
    });
    const health = await request(status.port, { path: "/health" });
    assert.equal(health.status, 200);
  } finally {
    await closeMcpServer(server);
    const blockerClosed = once(blocker, "close");
    blocker.close();
    await blockerClosed;
    removeProject(project);
  }
});

test("panel module exposes only functional messages", () => {
  const project = makeProject();
  setEditor(project);
  const panelPath = require.resolve("../dist/panels/default");
  delete require.cache[panelPath];
  const panel = require(panelPath);
  assert.match(panel.template, /id="app"/);
  assert.equal(typeof panel.ready, "function");
  assert.equal(typeof panel.close, "function");
  assert.deepEqual(Object.keys(panel.messages).sort(), [
    "onPreviewPlay",
    "onPreviewStop",
  ]);
  removeProject(project);
});

test("all 16 tool handlers load and reject empty calls cleanly", async () => {
  const project = makeProject();
  setEditor(project);
  const { CocosTools } = require("../dist/tools/cocos/cocos-tools");
  const tools = new CocosTools();

  for (const fullName of BASELINE_TOOL_NAMES) {
    const name = fullName.replace(/^cocos_/, "");
    const result = await tools.execute(name, {});
    assert.equal(typeof result, "object", `${fullName} returned no result`);
    assert.equal(result.success, false, `${fullName} accepted an empty call`);
    assert.equal(typeof result.error, "string", `${fullName} returned no error`);
  }

  removeProject(project);
});

test("message recorder has no identity fallback and preserves its functional contract", async () => {
  const recorderPath = require.resolve(
    "../dist/tools/cocos/utils/message-recorder",
  );
  delete require.cache[recorderPath];

  const originalRequest = async (...args) => ({ ok: true, args });
  const originalSend = (...args) => ["send", ...args];
  const originalBroadcast = (...args) => ["broadcast", ...args];
  globalThis.Editor = {
    Message: {
      request: originalRequest,
      send: originalSend,
      broadcast: originalBroadcast,
    },
  };

  const { MessageRecorder } = require(recorderPath);
  MessageRecorder.install();
  MessageRecorder.setSource("mcp");
  MessageRecorder.startRecording();

  assert.deepEqual(
    await globalThis.Editor.Message.request("scene", "query-node", "abc"),
    { ok: true, args: ["scene", "query-node", "abc"] },
  );
  assert.deepEqual(globalThis.Editor.Message.send("scene", "save"), [
    "send",
    "scene",
    "save",
  ]);
  assert.deepEqual(
    globalThis.Editor.Message.broadcast("scene", "ready", true),
    ["broadcast", "scene", "ready", true],
  );

  const records = MessageRecorder.stopRecording();
  assert.equal(records.length, 3);
  assert.deepEqual(
    records.map(({ dir, plugin, method, source }) => ({
      dir,
      plugin,
      method,
      source,
    })),
    [
      { dir: "request", plugin: "scene", method: "query-node", source: "mcp" },
      { dir: "send", plugin: "scene", method: "save", source: "mcp" },
      { dir: "broadcast", plugin: "scene", method: "ready", source: "mcp" },
    ],
  );
  assert.equal(MessageRecorder.getRecords({ dir: "send" }).length, 1);
  assert.equal(MessageRecorder.getRecords({ method: "query" }).length, 1);
  assert.equal(MessageRecorder.getRecords({ source: "mc" }).length, 3);
  assert.equal(MessageRecorder.getRecords({ limit: 2 }).length, 2);

  MessageRecorder.uninstall();
  assert.equal(globalThis.Editor.Message.request, originalRequest);
  assert.equal(globalThis.Editor.Message.send, originalSend);
  assert.equal(globalThis.Editor.Message.broadcast, originalBroadcast);

  delete globalThis.Editor;
  const exportDir = MessageRecorder.resolveExportDir();
  assert.equal(
    exportDir,
    path.join(os.tmpdir(), "cocos-mcp", "message-recorder"),
  );
  const exported = MessageRecorder.exportToFile();
  assert.equal(path.dirname(exported), exportDir);
  assert.equal(fs.readFileSync(exported, "utf8").trim().split("\n").length, 3);
  fs.rmSync(exported);

  MessageRecorder.clear();
  MessageRecorder.resetSource();
  assert.equal(MessageRecorder.count, 0);
  assert.equal(MessageRecorder._currentSource, "editor");
});

test("update checks are deterministic and perform no remote work", async () => {
  const checker = require("../dist/update-checker");
  checker.clearSkippedVersion();
  const result = await checker.checkForUpdateWithSkip();
  assert.equal(result.hasUpdate, false);
  checker.setSkippedVersion("1.7.9-test");
  assert.equal(checker.getSkippedVersion(), "1.7.9-test");
  checker.clearSkippedVersion();
  assert.equal(checker.getSkippedVersion(), null);
});

test("distribution has no gate modules, native payloads, gate routes, or gate messages", () => {
  const forbiddenPaths = [
    "dist/auth",
    "dist/sidecar-executor.js",
    "sidecar",
    ".gstack",
    "dist/tools/cocos/handlers/devtools-handler.js",
    "dist/panels/tool-manager",
    "static/template/default/tool-manager.html",
  ];
  for (const relativePath of forbiddenPaths) {
    assert.equal(
      fs.existsSync(path.join(ROOT, relativePath)),
      false,
      `${relativePath} must not be in the test package`,
    );
  }

  const strongMarkers = [
    "MCP_SUBSCRIPTION_AUTH",
    "_exec_toolbar",
    "executeJavaScript",
    "evalMain",
    "evalDevTools",
    "payload.enc",
    "checkLicense",
    "activateLicense",
    "deactivateLicense",
    "subscriptionStatus",
    "loginSubscription",
    "logoutSubscription",
    "getMachineId",
    "../auth",
    "/auth/",
    "device-identity",
    "sidecar-executor",
  ];
  const findings = [];
  for (const file of walkFiles(ROOT)) {
    const buffer = fs.readFileSync(file);
    if (buffer.includes(0)) continue;
    const text = buffer.toString("utf8");
    for (const marker of strongMarkers) {
      if (text.includes(marker)) {
        findings.push(`${path.relative(ROOT, file)}: ${marker}`);
      }
    }
  }
  assert.deepEqual(findings, []);

  const packageJson = require("../package.json");
  const messageNames = Object.keys(packageJson.contributions.messages);
  assert.equal(
    messageNames.some((name) =>
      /license|subscription|machine-id|login|logout|device-removed/i.test(
        name,
      ),
    ),
    false,
  );
});
